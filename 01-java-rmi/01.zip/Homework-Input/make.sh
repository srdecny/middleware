#!/bin/bash
export CLASSPATH=.
javac *.java
