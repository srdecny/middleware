#!/bin/sh

export CLASSPATH=.
java Main "$@"
